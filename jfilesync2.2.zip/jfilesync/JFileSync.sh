#!/bin/sh

DIR=`dirname $0`
java -jar $DIR/lib/jfs.jar $*
